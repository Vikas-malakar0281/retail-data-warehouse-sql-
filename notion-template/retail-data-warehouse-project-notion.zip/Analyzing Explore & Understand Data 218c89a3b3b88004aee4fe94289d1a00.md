# Analyzing: Explore & Understand Data

DWH EPIC: Build Silver Layer (Build%20Silver%20Layer%20218c89a3b3b8800bb303d20c474abc64.md)
ch: Yes