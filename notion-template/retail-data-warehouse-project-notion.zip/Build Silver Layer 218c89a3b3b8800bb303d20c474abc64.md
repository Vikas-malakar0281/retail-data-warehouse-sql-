# Build Silver Layer

Index: 5
Project Tast: Analyzing: Explore & Understand Data (Analyzing%20Explore%20&%20Understand%20Data%20218c89a3b3b88004aee4fe94289d1a00.md), Documentation: Draw Data Integration (Data.io) (Documentation%20Draw%20Data%20Integration%20(Data%20io)%20218c89a3b3b88007bb53d925ee0bccb9.md), Coding: Data cleansing (Coding%20Data%20cleansing%20218c89a3b3b880e4a061e0daf3539af0.md), Validating: Data Correctness Checks (Validating%20Data%20Correctness%20Checks%20218c89a3b3b88084963ad9f5af27ddb9.md), Documentation: Extended Data flow (draw.io) (Documentation%20Extended%20Data%20flow%20(draw%20io)%20218c89a3b3b880979243e29cdd04af8b.md), Commit the code in Git Repo (Commit%20the%20code%20in%20Git%20Repo%20218c89a3b3b880b791d6e33d3640adf7.md)
Rollup: 1