# Project Initialization

Index: 3
Project Tast: Create Git Repo & Prepare the Structure (Create%20Git%20Repo%20&%20Prepare%20the%20Structure%20218c89a3b3b8802a860ec78768e6d439.md), Create DB & Schemas (Create%20DB%20&%20Schemas%20218c89a3b3b880e1b889e1622f1e6b0b.md), Create Detail Project Tasks (Notion) (Create%20Detail%20Project%20Tasks%20(Notion)%20218c89a3b3b880d5983ac6fe99a99aca.md), Define Project Naming Conventions (Define%20Project%20Naming%20Conventions%20218c89a3b3b8809e9c03d32366451d91.md)
Rollup: 1