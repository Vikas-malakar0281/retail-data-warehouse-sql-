# Define Project Naming Conventions

DWH EPIC: Project Initialization (Project%20Initialization%20218c89a3b3b880f8b78dc45e0762ee79.md)
ch: Yes

[Define Project Naming Conventions](Define%20Project%20Naming%20Conventions%20218c89a3b3b88000847ac8563d609b27.md)