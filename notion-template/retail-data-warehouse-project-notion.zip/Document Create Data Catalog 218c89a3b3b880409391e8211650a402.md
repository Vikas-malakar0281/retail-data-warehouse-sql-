# Document: Create Data Catalog

DWH EPIC: Build Gold Layer (Build%20Gold%20Layer%20218c89a3b3b880b09ea2e00f89a2fd3a.md)
ch: Yes