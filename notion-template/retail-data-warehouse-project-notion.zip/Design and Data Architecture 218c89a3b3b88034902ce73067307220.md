# Design and Data Architecture

Index: 2
Project Tast:  Design the Layers (Design%20the%20Layers%20218c89a3b3b880ed9a3bc02aef968a18.md), Choose data management Approach (Choose%20data%20management%20Approach%20218c89a3b3b880ffa49ef8ecf0fb09d5.md), Draw the Data Architecture (Draw.io) (Draw%20the%20Data%20Architecture%20(Draw%20io)%20218c89a3b3b8806eb70cc24eede5d05f.md)
Rollup: 1