# Create Detail Project Tasks (Notion)

DWH EPIC: Project Initialization (Project%20Initialization%20218c89a3b3b880f8b78dc45e0762ee79.md)
ch: Yes