# Choose data management Approach

## Type of Data Architecture

- Data Warehouse
- Data Lake
- Data Lakehouse
- Data Mesh

In this project we are going with the  ‘Data Ware house’

## Approaches to Create the Data Warehouse

- Immon
- Kimbaff
- Data Vault
- Medallion Architecture

In this project we are going with ‘Medallion Architecture’