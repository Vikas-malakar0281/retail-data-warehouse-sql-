# Draw the Data Architecture (Draw.io)

DWH EPIC: Design and Data Architecture (Design%20and%20Data%20Architecture%20218c89a3b3b88034902ce73067307220.md)
ch: Yes

[DATA STRUCTURE.drawio](DATA_STRUCTURE.drawio)