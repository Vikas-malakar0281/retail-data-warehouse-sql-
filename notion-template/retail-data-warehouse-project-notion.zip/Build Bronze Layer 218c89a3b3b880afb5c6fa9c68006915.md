# Build Bronze Layer

Index: 4
Project Tast: Analyzing:  Source System (Analyzing%20Source%20System%20218c89a3b3b8805c86ace938e91dbf30.md), Coding: Data Ingestion  (Coding%20Data%20Ingestion%20218c89a3b3b88001b507dce1c8894d86.md), Validating: Data Completeness (Validating%20Data%20Completeness%20218c89a3b3b880a18e61ea0f3a4e09f7.md), Document: Data Draw Flow (Draw.io) (Document%20Data%20Draw%20Flow%20(Draw%20io)%20218c89a3b3b8804ca9f2e9161c39a720.md), Commit Code In Git Repo (Commit%20Code%20In%20Git%20Repo%20218c89a3b3b880da9d16d0f374d15e4e.md)
Rollup: 1