# Analyze & Understand The Requirement

DWH EPIC: Requirement and Analysis (Requirement%20and%20Analysis%20218c89a3b3b88063b8fdf6ba1bcd522a.md)
ch: Yes

[Project requirement](Project%20requirement%20218c89a3b3b880b59cfcd5f22269fa04.md)